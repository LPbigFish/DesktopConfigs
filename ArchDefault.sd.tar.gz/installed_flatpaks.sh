flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system io.github.achetagames.epic_asset_manager -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
